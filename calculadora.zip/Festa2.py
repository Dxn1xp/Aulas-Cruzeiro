print("Qual seu nome?")
nome = input()
print('Qual sua idade?')
idade = input()

print (f"Você é {nome} e tem {idade} de idade!")
