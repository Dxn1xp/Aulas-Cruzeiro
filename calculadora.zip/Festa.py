nota1 = 6
nota2 = 7
resultado = (nota1 + nota2)/2
nome = "Deni"
disciplina = "Programação de computadores"

print(f"o resultado do aluno {nome} da disciplina {disciplina} é igual a: {resultado}")