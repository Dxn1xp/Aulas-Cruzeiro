nota1 = 6
nota2 = 7
resultado = (nota1 + nota2)/2
print("Insira os 2 números")

print(f"O resultado é: {resultado}")