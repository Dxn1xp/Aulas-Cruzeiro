valor1 = int(input("Insira o primeiro valor:"))
valor2 = int(input("Insira o segundo valor:"))

adicao = (valor1 + valor2)
subtracao = (valor1 - valor2)
multiplicacao = (valor1*valor2)
divisao = (valor1/valor2)

print("Selecione um operador:")
print("1 - Adição")
print("2 - Subtração")
print("3 - Multiplicação")
print("4 - Divisão")

operador = input("Digite a opção (1, 2, 3 ou 4): ")

if operador == "1":
    print(f"Resultado: {adicao}")
elif operador == "2":
    print(f"Resultado: {subtracao}")
elif operador == "3":
    print(f"Resultado: {multiplicacao}")
elif operador == "4":
    print(f"Resultado: {divisao}")
else:
    print("Opção inválida")