print("Converter Celsius em Fahrenheit/Kelvin.")

print("Insira o valor:")
valor = int(input())

tF = (valor*1.8) + 32
tK = (valor + 273)

print(f"O resultado de {valor} em Fahrenheit é {tF} e o de Kelvin {tK}")