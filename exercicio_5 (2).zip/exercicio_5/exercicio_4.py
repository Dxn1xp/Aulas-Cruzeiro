print("Calculo de raizes")

a = int(input("Digite o valor de a: "))
b = int(input("Digite o valor de b: "))
c= int(input("Digite o valor de c: "))

delta = b**2 - 4*a*c

x1 = (-b + delta**0.5) / (2*a)
x2 = (-b - delta**0.5) / (2*a)

print(f"Seu resultado de x1: {x1} e de x2 é {x2}")