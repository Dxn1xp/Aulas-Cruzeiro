print("Qual valor da conta a pagar?")

valor = float(input())

taxa = 10
desconto = 0.05


valor_taxa = valor/taxa
resultado = (valor_taxa + valor)

valor_desconto = valor * desconto
valor_final_com_desconto = valor - valor_desconto
calculo = valor_final_com_desconto/taxa
resultado2 = (valor_final_com_desconto + valor_taxa)


if valor >= 1000:
    print(f"Você deve pagar {resultado2}")
else:
    print(f"Você deve pagar {resultado}")
