print("Conversão de Real em Dolar")

print("Digite o valor:")

valor = int(input())

calculodolar = valor/5.22

print(f"O resultado é {calculodolar}")

